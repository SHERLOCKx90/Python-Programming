import pickle as p
import time as t
def teacher():
    print("\n============= T E A C H E R    D A S H    B O A R D =============")
    print("1. Home\n\n2. resources\n\n3. tests\n\n4. assignments\n\n5. discussions\n\n6. payment\n\n7. changepassword\n\n8. notfications\n\n0. logout ")
    op = int(input("enter your option:"))
    if op==1:
        pass
    elif op==2:
        f = open("e:/resources.txt", "a")
        while True:
            try:
                print("press 1 to upload subject link")
                print("press 2 to update subject link")
                if op==1:
                    subj=input("enter subject:")
                    if subj == "physics":
                        print("++++++ PHYSICS ++++++")
                        up = input("upload physics link:")
                        z=f.write(\n)
                        z=f.write(up)
                        break
                    elif subj == "chemistry":
                        print("++++++ CHEMISTRY ++++++")
                        up = input("upload chemistry link:")
                        r=f.write(\n)
                        r=f.write(up)
                        break
                    elif subj == "mathematics":
                        print("++++++ MATHEMATICS ++++++")
                        up = input("upload mathematics link:")
                        c=f.write(\n)
                        c=f.write(up)
                        break
                    else:
                        print("invalid")
                        break
                #elif op==2:
            except EOFError:
                print("thank you!")
                break
        f.close()


def student():
    print("\n============= S T U D E N T    D A S H    B O A R D =============")
    print("1. Home\n\n2. resources\n\n3. tests\n\n4. assignments\n\n5. discussions\n\n6. payment\n\n7. changepassword\n\n8. notfications\n\n0. logout ")
    op=int(input("enter your option:"))
    if op==1:
        pass
    elif op==2:
        f=open("e:/resources.txt","r")
        r = f.readlines()
        while True:
            try:
                subj = input("enter subject:")
                for i in range(len(r)):
                    if subj=="physics":
                        print(r[0])
                        print("click the link to get your required pdf file")
                        print()
                        break
                    elif subj=="chemistry":
                        print(r[1])
                        print("click the link to get your required pdf file")
                        break
                    elif subj=="mathematics":
                        print(r[2])
                        print("click the link to get your required pdf file")
                        break
                    else:
                        print("invalid")
                        break
            except EOFError:
                print("thank you!")
                break
        f.close()
    elif op==3:
        f=open("e:/test.py","rb")
        while True:
            try:
                rec=p.load(f)
#main_section
print("press 1 to login as teacher")
print("press 2 to login as student")
op=int(input("enter option:"))
if op==1:
    teacher()
elif op==2:
    student()
else:
    print("invalid opition!")